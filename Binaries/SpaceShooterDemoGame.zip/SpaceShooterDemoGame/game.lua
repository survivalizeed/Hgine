--To be called during the runtime

enemy_lives = 15