window_size_overall = 500	--Because window needs to be quad

configuration = {
	debug_mode = 0,
	application_name = "SpaceShooter Demo",
	window_size_x = window_size_overall,
	window_size_y = window_size_overall,
	resource_path = ".\\Resource\\",
	sound_path = ".\\Sounds\\"
}


