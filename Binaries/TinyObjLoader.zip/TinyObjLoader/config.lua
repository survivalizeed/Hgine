window_size_overall = 750	--Because window needs to be quad

configuration = {
	debug_mode = 0,
	application_name = "Tiny Loader",
	window_size_x = 1000,
	window_size_y = 750,
	resource_path = "NONE",
	sound_path = ".\\audio\\"
}
