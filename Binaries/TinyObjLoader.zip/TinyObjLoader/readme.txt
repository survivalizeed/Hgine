Controls:

w = forward
s = backward
a = left
d = right
e = up
q = down

j = rotateX
k = rotateY
l = rotateZ

===========================

The application will ask for a file name.
To enter the obj folder in this folder, just enter:
.\obj\someObj.obj
