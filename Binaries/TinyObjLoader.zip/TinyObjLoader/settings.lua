-- they are all not the same speed because of the euler gimbal lock
incAngleX = 1.1
incAngleY = 1.2
incAngleZ = 1.3
music = 1
